/*
PROBLEM STATEMENT
Write a C program to carry out following operations on strings using library functions- a) To concatenate a string S2 to string S1
b) To find the length of a given string
c) To compare two strings S1 and S2
d) To copy a string S2 to another string S1
*/
