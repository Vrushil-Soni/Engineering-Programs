/*
PROBLEM STATEMENT
A mall has 5 stores and 3 departments. Write a C program with function to find the monthly sale of a particular store or department and the total monthly sale of each store and each department.
*/
