
/*
PROBLEM STATEMENT
Write a C program that stores 12 city names in a single dimensional array. Write function to display only those words that begin with a consonant and end with a vowel example- Begaluru, Mumbai
*/
