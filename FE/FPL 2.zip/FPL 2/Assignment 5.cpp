#include <iostream>
 
using namespace std;
 
int main()
{
   int a, b, c;
   
   cout << "Enter two integers to add\n";
   cin >> a >> b;
 
   c = a + b;
   cout <<"Sum of the numbers: " << c << endl;
   
   return 0;
}