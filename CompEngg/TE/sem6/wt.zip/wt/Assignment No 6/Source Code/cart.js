var app=angular.module('myapp',[]);
		app.controller('CartForm', function($scope)
{
    $scope.cart = [{qty: '',description: '',cost: ''} ];
    $scope.addItem = function() {
        $scope.cart.push({qty: '',description: '',cost: ''});
    },
    $scope.removeItem = function(index) {
        $scope.cart.splice(index, 1);
		//index at which to start changing the array
		// how many elements are to be removed from old array if zero not removed
    },
    $scope.total = function() {
        var total = 0;
        angular.forEach($scope.cart, function(item) {
            total += item.qty * item.cost;
        })
        return total;
    }
}
);