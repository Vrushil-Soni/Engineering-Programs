<html>
<head>
<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    }
	else {
            xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","profile.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<body>

<form>
<center>
<b>
<label>Please Enter Name for Search Profile</b></label> 
<input type="text" name="username" oninput="showUser(this.value)"></center>
</form>
<br>
<div id="txtHint"><b>Your Profile Display Here...</b></div>

</body>
</html> 
