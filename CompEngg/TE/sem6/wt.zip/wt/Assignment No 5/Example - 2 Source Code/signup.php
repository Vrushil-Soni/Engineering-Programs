
<html>

<head>
<title>Form Input Data</title>
<script>
function chkuser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    }
	else {
       if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } 
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","userchk.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>

<body>
<center>
<table border="1">
  <tr>
    <td align="center">Sign Up Form</td>
  </tr>
  <tr>
    <td>
      <table>
        <form method="post" action="create_account.php">
        
	<tr>
          <td>UserName</td>
          <td><input type="text" name="username" oninput="chkuser(this.value)" size="20">
          <span><div id="txtHint"><b></b></div></span>
		  </td>
        </tr>
        <tr>
          <td>Password</td>
          <td><input type="text" name="password" size="20">
          </td>
        </tr>
	          <td align="right"><input type="submit" name="submit" value="Sent"></td>
        </tr>
	
        </table>
      </td>
    </tr>
</table>
</center>
</body>
</html>
