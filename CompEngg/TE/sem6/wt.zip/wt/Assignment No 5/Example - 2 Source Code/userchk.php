<?php
$con=mysqli_connect("localhost","root","VEERA");
mysqli_select_db($con, "login");

if (!$con) 
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$user_check = $_GET['q'];
$query1="select username from users where username='$user_check'";
$res1=mysqli_query($con, $query1);
$count=mysqli_num_rows($res1);
if($count!=0)
{
  echo "username already exist";
}
else{
	echo "username available";
}
mysqli_close($con);
?>

