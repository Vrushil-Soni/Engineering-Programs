<?php

$con=mysqli_connect("localhost","root","VEERA");
mysqli_select_db($con, "login");

if (!$con) 
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
echo "success";

}
$query="INSERT INTO users (username,password)VALUES('$_POST[username]','$_POST[password]')";
$res=mysqli_query($con, $query);

if ($res) 
{
echo "login created successfully"
}
else 
{
    echo "Error: " . $res . "<br>" . mysqli_error($con);
}
mysqli_close($con);
?>

