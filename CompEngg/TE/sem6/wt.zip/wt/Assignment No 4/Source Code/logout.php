<?php
session_start();
session_unset();
session_destroy();
echo "successfully logged out";

/*
if(session_destroy()) // Destroying All Sessions
{
header("Location: login.php"); // Redirecting To Home Page
}
*/
?>