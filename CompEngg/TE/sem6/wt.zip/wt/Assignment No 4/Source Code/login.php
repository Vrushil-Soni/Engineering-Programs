<?php

session_start(); 

if(isset($_SESSION['login_user']) != "")
	{
		//echo "You are not logged in<br/>";
         //echo "<a href=\"profile.php\">Please Login</a>";
		header('location: profile.php');
}


	?>
<html>

<head>
	<title>Login Form in PHP with Session</title>
	
</head>

<body>

<h1>PHP Login Session Example</h1>

<h2>Login Form</h2>
<a href="signup.php">Sign up</a>

<form action="login_check.php" method="post">

<label>UserName :</label>

<input id="name" name="username" placeholder="username" type="text">

<label>Password :</label>

<input id="password" name="password" placeholder="**********" type="password">

<input name="submit" type="submit" value=" Login ">
 
</form>


</body>

</html>
