<?php

session_start(); 

if(isset($_SESSION['login_user']) != "")
	{
		//echo "You are not logged in<br/>";
         //echo "<a href=\"profile.php\">Please Login</a>";
		header('location: profile.php');
}


?>
<html>

<head>
<title>Form Input Data</title>
</head>

<body>
<center>
<table border="1">
  <tr>
    <td align="center">Sign Up Form</td>
  </tr>
  <tr>
    <td>
      <table>
        <form method="post" action="adduser.php">
        
	<tr>
          <td>UserName</td>
          <td><input type="text" name="username" size="20">
          </td>
        </tr>
        <tr>
          <td>Password</td>
          <td><input type="text" name="password" size="20">
          </td>
        </tr>
	          <td align="right"><input type="submit" name="submit" value="Sent"></td>
        </tr>
	
        </table>
      </td>
    </tr>
</table>
</center>
</body>
</html>
