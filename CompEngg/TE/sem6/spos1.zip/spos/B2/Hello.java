/*Assignment 6: Write a program using Lex specifications to implement lexical analysis phase of compiler to generate tokens of subset of a Java program.*/

import java.util.*;
class Hello
{
	public static void main(String []args)
	{
		System.out.println("Hello World");
	}
}
