import java.util.Scanner;

class fcfs
{
	public static void main(String args[]) 
	{ 
        
		Scanner in = new Scanner(System.in); 
	  
		System.out.println("ENTER NUMBER OF PROCESSES "); 
		int num = in.nextInt(); 

		System.out.println("ENTER ARRIVAL TIME "); 
		int[] at=new int[num];

		for(int i=0;i<num;i++)
		{
			System.out.println("FOR PROCESS "+(i+1));
			at[i]=in.nextInt();
		}

		System.out.println("ENTER BURST TIME "); 
		int[] bt=new int[num];

		for(int i=0;i<num;i++)
		{
			System.out.println("FOR PROCESS "+(i+1));
			bt[i]=in.nextInt();
		}
		
		int[] pid = new int[num];
		int[] ct = new int[num];     
		int[] ta = new int[num];     
		int[] wt = new int[num];
		float avg_w=0, avg_t=0;
		int temp;
		
		for(int i=0;i<num;i++)
		{
			pid[i] = i+1;
		}
		for(int i = 0 ; i <num; i++)
		{
			for(int  j=0;  j < num-(i+1) ; j++)
			{
				if( at[j] > at[j+1] )
				{
					temp = at[j];
					at[j] = at[j+1];
					at[j+1] = temp;
					temp = bt[j];
					bt[j] = bt[j+1];
					bt[j+1] = temp;
					temp = pid[j];
					pid[j] = pid[j+1];
					pid[j+1] = temp;
				}
			}
		}
		
		for(int  i = 0 ; i < num; i++)
		{
			if( i == 0)
			{	
				ct[i] = at[i] + bt[i];
			}
			else
			{
				if( at[i] > ct[i-1])
				{
					ct[i] = at[i] + bt[i];
				}
				else
					ct[i] = ct[i-1] + bt[i];
			}
			ta[i] = ct[i] - at[i] ;          
			wt[i] = ta[i] - bt[i] ;          
			avg_w += wt[i] ;               
			avg_t += ta[i] ;               
		}		
		System.out.println("\nPROCESS    ARRIVAL TIME    BURST TIME    COMPLETION TIME    TURNAROUND TIME    WAITING TIME");
		for(int  i = 0 ; i< num;  i++)
		{
			System.out.println(pid[i] + "  \t\t " + at[i] + "\t\t" + bt[i] + "\t\t" + ct[i] + "\t\t" + ta[i] + "\t\t"  + wt[i] ) ;
		}
		System.out.println("\nAVERAGE WAITING TIME IS : "+ (avg_w/num));     
		System.out.println("AVERAGE TURNAROUND TIME IS :"+(avg_t/num));
	}
	
}
