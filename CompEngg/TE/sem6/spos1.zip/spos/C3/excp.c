#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	pid_t c_pid;
	c_pid=fork();
	if(c_pid==0)
	{
		printf("Child:%d\n",c_pid);
		printf("\n");
	}else if(c_pid > 0){
		printf("Parent:%d\n",c_pid);
	}else{
		perror("fork failed");
		
	}
return 0;

}
