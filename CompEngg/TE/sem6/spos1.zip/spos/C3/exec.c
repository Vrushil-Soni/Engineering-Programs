
#include<stdio.h>
#include<unistd.h>

int main()
{
    int i;

    printf("Welcome to spos lab... ");
    printf("\nWe have perform exec family system call\n ");

    return 0;
}
