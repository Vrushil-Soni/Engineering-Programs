#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>

int main()
{
   pid_t cpid;
	if(fork()==0)
		exit(0);	//terminate child
	else
		cpid=wait(NULL);	//reaping parent
	printf("\n Parent pid=%d" ,getpid());
	printf("\n Child pid=%d \n\n",cpid);
    return 0;
}
