#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main ()
{
    system("ps");
    return 0;
}

