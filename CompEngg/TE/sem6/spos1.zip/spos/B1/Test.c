#include<stdio.h>
#include<math.h>
#include<string.h>
#include<jni.h>
#include"TEST.h"

JNIEXPORT jint JNICALL Java_TEST_add
  (JNIEnv *env, jobject obj, jint n1, jint n2)
{
 jint c;
 c=n1+n2;
 return c;
}

JNIEXPORT jint JNICALL Java_TEST_sub
  (JNIEnv *env, jobject obj, jint n1, jint n2)
{
 jint c;
 c=n1-n2;
 return c;
}

JNIEXPORT jint JNICALL Java_TEST_mul
  (JNIEnv *env, jobject obj, jint n1, jint n2)
{
 jint c;
 c = n1 * n2;
 return c;
}

JNIEXPORT jint JNICALL Java_TEST_div
  (JNIEnv *env, jobject obj, jint n1, jint n2)
{
 jint c;
 c = n1 / n2;
 return c;
}

JNIEXPORT jdouble JNICALL Java_TEST_sinf
  (JNIEnv *env, jobject obj, jdouble rad)
{
 jdouble c;
 c = sin(rad);
 return c;
}

JNIEXPORT jdouble JNICALL Java_TEST_cosf
  (JNIEnv *env, jobject obj, jdouble rad)
{
 jdouble c;
 c = cos(rad);
 return c;
}

JNIEXPORT jstring JNICALL Java_TEST_concat
  (JNIEnv *env, jobject obj, jstring n1, jstring n2)
{
   const char *str1 = (*env)->GetStringUTFChars(env, n1, 0);
   const char *str2 = (*env)->GetStringUTFChars(env, n2, 0);
   char result[200];
   strcat(result, str1);
   strcat(result, str2);

   jstring jstrBuf = (*env)->NewStringUTF(env, result);

   (*env)->ReleaseStringUTFChars(env, n1, str1);
   (*env)->ReleaseStringUTFChars(env, n2, str2);

   return jstrBuf;
}
