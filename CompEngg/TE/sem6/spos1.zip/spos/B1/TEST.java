import java.util.Scanner;

public class TEST
{
static{
System.loadLibrary("hello");
}

private native int add(int a,int b);

private native int sub(int a,int b);

private native int mul(int a,int b);

private native int div(int a,int b);

private native double sinf(double radians);

private native double cosf(double radians);

private native String concat(String c,String d);

public static void main(String args[])
 { 
 Scanner sc = new Scanner(System.in);
 char ch1;
 int a,b,ch2;
 double degrees,radians;
 do{
   System.out.println("Enter Operation to be Performed: ");
   System.out.println("1.Addition");
   System.out.println("2.Subtraction");
   System.out.println("3.Multiplication");
   System.out.println("4.Divsion");
   System.out.println("5.Sin");
   System.out.println("6.Cos");
   System.out.println("7.Concat");
   ch2 = sc.nextInt();
   switch(ch2)
   {
     case 1:System.out.println("Enter 2 numbers: ");
            a = sc.nextInt();
            b = sc.nextInt();
            System.out.println("Addition is: " +new TEST().add(a, b));
            break;
     case 2:System.out.println("Enter 2 numbers: ");
            a = sc.nextInt();
            b = sc.nextInt();
            System.out.println("Subtraction is: " +new TEST().sub(a, b));
            break;
     case 3:System.out.println("Enter 2 numbers: ");
            a = sc.nextInt();
            b = sc.nextInt();
            System.out.println("Multiplication is: " +new TEST().mul(a, b));
            break;
     case 4:System.out.println("Enter 2 numbers: ");
            a = sc.nextInt();
            b = sc.nextInt();
            System.out.println("Divsion is: "+new TEST().div(a, b));
            break;
     case 5:System.out.println("Enter angle in degrees: ");
            degrees = sc.nextDouble();
            radians = Math.toRadians(degrees);
            System.out.println("Sin value is: "+new TEST().sinf(radians));
            break;
     case 6:System.out.println("Enter angle in degrees: ");
            degrees = sc.nextDouble();
            radians = Math.toRadians(degrees);
            System.out.println("Cos value is: "+new TEST().cosf(radians));
            break;
     case 7:String c,d;
            System.out.println("Enter 2 Strings to Concatenate: ");
            c = sc.next();
            d = sc.next();
            sc.reset();
            System.out.println("Concatenation is: "+new TEST().concat(c, d));
            break;
   }
    System.out.println("Do you want to continue(y/n)? ");
    ch1 = sc.next().charAt(0);
  }while(ch1=='Y' || ch1=='y');
 }
}
/*
1.javac B1.java 
2.javah -classpath . B1
3.type ls to check B1.h
4.gcc -shared -fPIC -I/usr/lib/jvm/default_java/include -I/usr/lib/jvm/default_java/include/linux B1.c -o libB1.so
5.java -classpath . -Djava.library.path=. B1
*/