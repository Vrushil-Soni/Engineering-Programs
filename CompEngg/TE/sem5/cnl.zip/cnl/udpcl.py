import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

if len(sys.argv) != 3:
    print "Correct usage: script, IP address, port number"
    exit()
IP_address = str(sys.argv[1])
Port = int(sys.argv[2])
sock.sendto("Hello Server", (IP_address, Port))

while True:    	
	msg, (ip, port) = sock.recvfrom(100)

	if "stop." in msg:
		break
	
	else:			
		print "server: " + msg
	
	msg = raw_input("you: ")

	sock.sendto(msg, (ip,port))
	
	if "stop." in msg:
		break
sock.close()

