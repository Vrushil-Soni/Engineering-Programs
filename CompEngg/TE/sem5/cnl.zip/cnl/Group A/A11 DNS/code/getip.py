import socket

domain_name=raw_input("Insert doamin_name:")
ip_address=socket.gethostbyname(domain_name)
print(ip_address)

domain_ip=raw_input("Insert doamin IP:")
domain_rec=socket.gethostbyaddr(domain_ip)
print(domain_rec)
print(domain_rec[0])

