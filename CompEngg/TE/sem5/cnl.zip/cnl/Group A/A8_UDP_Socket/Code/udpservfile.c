#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<netinet/in.h> 
#include<unistd.h>
#include<string.h> 

void main()
{
int b,udpsockfd;
char buffer[10000];

if((udpsockfd=socket(AF_INET,SOCK_DGRAM,0))>=0)  
printf("socket created sucessfully \n");
                                                 
struct sockaddr_in servaddr, clientaddr;              

servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
servaddr.sin_port=6000;


if((b=bind(udpsockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)))==0)   
printf("bind Sucessful \n");

int sin_size=sizeof(clientaddr);

recvfrom(udpsockfd, buffer, 10000, 0, (struct sockaddr *)&clientaddr, &sin_size);   

FILE *fp;
fp= fopen("/home/receive1.txt", "w+");

/* Read and display data */
fwrite(buffer,  1, strlen(buffer) + 1, fp);

printf("Received File Contents :%s \n", buffer);
fclose(fp);
close(udpsockfd);
}
