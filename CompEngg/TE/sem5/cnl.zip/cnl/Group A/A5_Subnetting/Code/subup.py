#import sys
import math
# take input as an IP address and Subnet no

address=raw_input("Enter IP Address: ")
subnet=raw_input("Enter Number of Subnet: ")

#Decide how many bits are needed to mask
mbit=math.log(float(subnet))/math.log(2)
mbit=math.ceil(mbit)
mbit=int(mbit)
#print mbit

#Convert IP In list
addr = address.split('.')

#print "addresss convert into list" + str(addr)
#print addr[0]

#Check Class of IP Address to Decide how many total bits to find netmask
if (addr[0] < '126'):
 print "This IP address belongs to Class A" 
 cidr= 8 + mbit

elif (addr[0] < '192' and addr[0] > '127'):
 print "This IP address belongs to Class B" 
 cidr= 16 + mbit

elif (addr[0] < '223' and addr[0] > '191'):
 print "This IP address belongs to Class A" 
 cidr= 24 + mbit

print "total Number of bits in network is for mask:", cidr

#Find Subnet Mask
mask = [0, 0, 0, 0]

for i in range(cidr):
       
	mask[i/8] = mask[i/8] + (1 << (7 - i % 8))
        
#Find Network Id     	        

net = []

for i in range(4):
	net.append(int(addr[i]) & mask[i])
	
#Find Broadcast IP
broad = list(net)
brange = 32 - cidr

for i in range(brange):
	broad[3 - i/8] = broad[3 - i/8] + (1 << (i % 8))
       

#Print full information
print "IP Address:   " , address
print "Netmask Address:   " , ".".join(map(str, mask))
print "Network Address:   " , ".".join(map(str, net))
print "Broadcast Address: " , ".".join(map(str, broad))
