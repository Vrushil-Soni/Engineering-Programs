import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect(('127.0.0.1',23000))

sock.send("HEllo Server msg from Client")

msg = sock.recv(16)
print "server: " + msg
sock.close()




