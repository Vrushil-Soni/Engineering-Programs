import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.bind(('localhost',23000))

sock.listen(1)

clisock, (ip,port) = sock.accept()

	
msg = clisock.recv(16)

print "client: " + msg
	

clisock.send("Hello Client msg from server")

sock.close()
            
