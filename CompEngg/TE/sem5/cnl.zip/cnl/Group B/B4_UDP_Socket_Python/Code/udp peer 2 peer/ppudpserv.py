import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', 10000))

msg, (ip, port) = sock.recvfrom(100)

print "client connected to ip: " + ip + " and port: " + str(port)
print "received message: " + msg

sock.sendto("Hello Client", (ip,port))


while True:    	
	msg, (ip, port) = sock.recvfrom(100)
	
	if "stop." in msg:
		break
	
	else:			
		print "client: " + msg
	
	msg = raw_input("you: ")
	sock.sendto(msg, (ip,port))
	
	if "stop." in msg:
		break
sock.close()
        

