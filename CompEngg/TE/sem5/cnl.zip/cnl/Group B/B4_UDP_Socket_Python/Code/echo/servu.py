import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', 10000))

msg, (ip, port) = sock.recvfrom(100)
print "Client:" +msg

sock.sendto("Hello Client", (ip,port))

sock.close()
