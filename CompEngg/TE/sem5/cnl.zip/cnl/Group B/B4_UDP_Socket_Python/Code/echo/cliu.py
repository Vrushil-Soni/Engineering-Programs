import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto("Hello Server", ('', 10000))

msg, (ip, port) = sock.recvfrom(100)
print "server: " + msg
sock.close()
