/* 
            stack(X,Y):  put block X on block Y
            Pre: CLEAR(y)^HOLDING(x)
            Add: ARMEMPTY^On(x,y)^CLEAR(x)
            Del:CLEAR(y)^HOLDING(x)
            
            
            unstack(X,Y): remove block X from block Y
            Pre: On(x,y)^CLEAR(x)^ARMEMPTY()
            Add:HOLDING(x)^CLEAR(y)
            Del:On(x,y)^CLEAR(x)^ARMEMPTY()
            
            
            pickup(X):pick up block X from the table
            Pre:ONTABLE(x)^CLEAR(x)^ARMEMPTY()
            Add:HOLDING(x)
            Del:ONTABLE(x)^CLEAR(x)^ARMEMPTY()
            
            
            
            putdown(X): put block X on the table
            Pre:HOLDING(x)
            Add:ONTABLE(x)^ARMEMPTY^CLEAR(x)
            Del:HOLDING(x)
            
*/

import java.util.*;
class Planner{
	static Stack<String> goalStack = new Stack<>();
	
	//static String start_state="ONTABLE(B) ^ ONTABLE(A) ^ ON(C,A) ^ ARMEMPTY ^ CLEAR(C) ^ CLEAR(B)";
	//static String goal_state="ONTABLE(C) ^ ON(B,C) ^ ON(A,B) ^ ARMEMPTY ^ CLEAR(A)";
	
	//static String start_state="ON(B,A) ^ ONTABLE(A) ^ ONTABLE(C) ^ ONTABLE(D) ^ ARMEMPTY ^ CLEAR(B) ^ CLEAR(C) ^ CLEAR(D)";
	//static String goal_state="ON(B,D) ^ ON(C,A) ^ ONTABLE(A) ^ ONTABLE(D) ^ CLEAR(B) ^ CLEAR(C)";
	
	static String start_state="ONTABLE(B) ^ ONTABLE(C) ^ ON(A,C) ^ ON(D,B) ^ ARMEMPTY ^ CLEAR(D) ^ CLEAR(A)";
	static String goal_state="ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)";
	
	
    //static String goal_state="ON(C,A) ^ ON(B,D) ^ ONTABLE(A) ^ ONTABLE(D) ^ CLEAR(B) ^ CLEAR(C)"; 
	static ArrayList<String> current_state;
    static ArrayList<String> action_list=new ArrayList<>();
	
	
	public static void list_operate(ArrayList<String> lp,ArrayList<String> la,ArrayList<String> ld,boolean alltrue){
        if(!alltrue){
            //System.out.println(":::PRE:::");
            for(String as:lp){
           //ADD Preconditions to Goal Stack 
            goalStack.push(as);
	        }
	    }
	    else{
              //System.out.println(":::ADD:::");
              for(String as:la){
	         //System.out.println(as);
	         //IF all preconditons pop add items to state
	                if(!current_state.contains(as.trim())){
	                    current_state.add(as.trim());
	                }
	        }
	          //System.out.println(":::DEL:::");
              for(String as:ld){
	         //System.out.println(as);
	         //IF all preconditons pop, delete items from current state  
	             if(current_state.contains(as.trim())){
	                  current_state.remove(as.trim());
	             }
	          }
	      }
	}
	
	public static void stack(char x,char y,boolean alltrue){
	    String Pre="HOLDING("+x+")^CLEAR("+y+")";
        String Add="ARMEMPTY^ON("+x+","+y+")^CLEAR("+x+")";
        String Del="CLEAR("+y+")^HOLDING("+x+")";
        ArrayList<String> lp=list_assertion(Pre);
        ArrayList<String> la=list_assertion(Add);
        ArrayList<String> ld=list_assertion(Del);
        if(!alltrue){
           goalStack.push("STACK("+x+","+y+")");
           goalStack.push(Pre);
        }
        list_operate(lp,la,ld,alltrue);
	}
	public static void unstack(char x,char y,boolean alltrue){
        String Pre="ON("+x+","+y+")^CLEAR("+x+")^ARMEMPTY";
        String Add="HOLDING("+x+")^CLEAR("+y+")";
        String Del="ON("+x+","+y+")^CLEAR("+x+")^ARMEMPTY";    
        ArrayList<String> lp=list_assertion(Pre);
        ArrayList<String> la=list_assertion(Add);
        ArrayList<String> ld=list_assertion(Del);
        if(!alltrue){
           goalStack.push("UNSTACK("+x+","+y+")");
           goalStack.push(Pre);
        }
        list_operate(lp,la,ld,alltrue);   
	}
	public static void pickup(char x,boolean alltrue){
	    String Pre="ONTABLE("+x+")^CLEAR("+x+")^ARMEMPTY";
        String Add="HOLDING("+x+")";
        String Del="ONTABLE("+x+")^CLEAR("+x+")^ARMEMPTY";          
        ArrayList<String> lp=list_assertion(Pre);
        ArrayList<String> la=list_assertion(Add);
        ArrayList<String> ld=list_assertion(Del);
        if(!alltrue){
           goalStack.push("PICKUP("+x+")");
           goalStack.push(Pre);
        }
        list_operate(lp,la,ld,alltrue);   
	}
	public static void putdown(char x,boolean alltrue){
	    String Pre="HOLDING("+x+")";
        String Add="ONTABLE("+x+")^ARMEMPTY^CLEAR("+x+")";
        String Del="HOLDING("+x+")";
        ArrayList<String> lp=list_assertion(Pre);
        ArrayList<String> la=list_assertion(Add);
        ArrayList<String> ld=list_assertion(Del);
        if(!alltrue){
           goalStack.push("PUTDOWN("+x+")");
           goalStack.push(Pre);
        }
        list_operate(lp,la,ld,alltrue);   
	}
	public static ArrayList<String> list_assertion(String compound){
	    ArrayList<String> maker =new ArrayList<>();
	    String assertion[] = compound.split("['^']");
	    for(String as:assertion){
	        //System.out.println(sg.trim());
	      maker.add(as.trim());
	    }
	    return maker;
	}
	
	public static void main(String args[]){
	
	    //List of Assertions that are True which make the state description
        current_state=list_assertion(start_state);
	    
	    //Push Final State and SubGoals onto Stack
	    goalStack.push(goal_state);
	    String subgoals[] = goal_state.split("['^']");
	    for(String sg:subgoals){
	      goalStack.push(sg.trim());
	    }
	    boolean b=true;
	    String s="ON(a,b)";
	    //char p='b';
	    //System.out.println(s.matches("ON\\(.,"+p+"\\)"));if(b)return;
	      //stack('a','b',false);
	    //show_stack();
	    char t='\0';
	    char x='\0';
	    char y='\0';
	    String temp="";
	    ArrayList<String> simple;
	     while(!goalStack.empty()){
	         show_stack();
	      //   try{Thread.sleep(5000);}
	        // catch(Exception e){e.printStackTrace();}
	         String top=goalStack.pop();
	         //System.out.println("Check if "+top+" holds true");
	         if(current_state.contains(top)){ 
	            System.out.println(top+" True pushed off Stack");
	            //show_stack();
	         }
	         else if(top.contains("^")){
	            //SPLIT AND RESTACK
	            System.out.println(top+" Compound Split Before Re-entry"); 
	            simple=list_assertion(top);
	            for(String sp:simple){
	                goalStack.push(sp);
	            }
	         }
	         else{
	            if(top.contains("ONTABLE")){
	                x=top.charAt(8);
	                putdown(x,false);
	                System.out.println(top+" False Replaced with action"); 
	            
	            }
	            else if(top.contains("ON")){
	                x=top.charAt(3);
	                y=top.charAt(5);
	                stack(x,y,false);
	                System.out.println(top+" False Replaced with action");
	                //show_stack();
	            }
	            else if(top.contains("ARMEMPTY")){
	                //check for holding and put down OR STACK 
	                for(String assertion:current_state){
	                    if(assertion.contains("HOLDING")){
	                        temp=assertion;
	                    }
	                }
	                x=temp.charAt(8);
	                putdown(x,false);
	                System.out.println(top+" False Replaced with action");
	                
	            }
	            else if(top.contains("HOLDING")){
	                x=top.charAt(8);
	                if(current_state.contains("ONTABLE("+x+")")){
	                    pickup(x,false);
	                }
	                else{
	                    for(String assertion:current_state){
	                        if(assertion.contains("ON("+x+",")){
	                            temp=assertion;
	                        }
	                    }
	                   y=temp.charAt(5);
	                   unstack(x,y,false); 
	                }
	                
	                System.out.println(top+" False Replaced with action");
	            }
	            else if(top.contains("CLEAR")){
	            //INCOMPLETE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	                y=top.charAt(6);
	                //look for on(?,t)
	                //unstack(?,t)
	                for(String assertion:current_state){
	                        if(assertion.matches("ON\\(.,"+y+"\\)")){
	                            temp=assertion;
	                        }
	                    }
	                   x=temp.charAt(3);
	                unstack(x,y,false);
	                
	                System.out.println(top+" False Replaced with action");    
	                //goalStack.push(top);     
	            }
	            else if(top.contains("UNSTACK")){
	                x=top.charAt(8);
	                y=top.charAt(10);
	                unstack(x,y,true);
	                action_list.add("UNSTACK("+x+","+y+")");
	                System.out.println("Action Performed  :::::UNSTACK("+x+","+y+")");
	            }
	            else if(top.contains("STACK")){
	                x=top.charAt(6);
	                y=top.charAt(8);
	                stack(x,y,true);
	                action_list.add("STACK("+x+","+y+")");
	                System.out.println("Action Performed  :::::STACK("+x+","+y+")");
	            }
	            else if(top.contains("PICKUP")){
	                x=top.charAt(7);
	                pickup(x,true);
	                action_list.add("PICKUP("+x+")");
	                System.out.println("Action Performed  :::::PICKUP("+x+")");
	            }
	            else if(top.contains("PUTDOWN")){
	                x=top.charAt(8);
	                putdown(x,true);
	                action_list.add("PUTDOWN("+x+")");
	                System.out.println("Action Performed  :::::PUTDOWN("+x+")");
	            }
	           else{goalStack.push(top);}
	         }
	         
	        //System.out.println(goalStack.pop());   
	     }
	     System.out.println("--Steps to perfrom--");
	     for(String action:action_list){
	        System.out.println(action);
	     }
	     
	   // show_stack();
	    //	    show_stack();
	}
	
	public static void show_stack(){
	
	    System.out.println("-----------");
	    Stack<String> tStack = new Stack<>();
	    String temp="";
	    while(!goalStack.empty()){
	     temp=goalStack.pop();   
	     System.out.println(temp);
	     tStack.push(temp);   
	    }
	    
	    while(!tStack.empty()){
	     goalStack.push(tStack.pop());     
	    }
	 
	    System.out.println("-----------");   
	}
}



/*
vrushil@vrushil:~$ cd AIR
vrushil@vrushil:~/AIR$ javac Planner.java
vrushil@vrushil:~/AIR$ java Planner
-----------
CLEAR(D)
ARMEMPTY
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(D) True pushed off Stack
-----------
ARMEMPTY
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,C) False Replaced with action
-----------
CLEAR(C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) False Replaced with action
-----------
ARMEMPTY
CLEAR(A)
ON(A,C)
ON(A,C)^CLEAR(A)^ARMEMPTY
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(A)
ON(A,C)
ON(A,C)^CLEAR(A)^ARMEMPTY
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(A) True pushed off Stack
-----------
ON(A,C)
ON(A,C)^CLEAR(A)^ARMEMPTY
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(A,C) True pushed off Stack
-----------
ON(A,C)^CLEAR(A)^ARMEMPTY
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(A,C)^CLEAR(A)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(A)
ON(A,C)
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(A)
ON(A,C)
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(A) True pushed off Stack
-----------
ON(A,C)
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(A,C) True pushed off Stack
-----------
UNSTACK(A,C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::UNSTACK(A,C)
-----------
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(D) False Replaced with action
-----------
ARMEMPTY
CLEAR(D)
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY False Replaced with action
-----------
HOLDING(A)
HOLDING(A)
PUTDOWN(A)
CLEAR(D)
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(A) True pushed off Stack
-----------
HOLDING(A)
PUTDOWN(A)
CLEAR(D)
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(A) True pushed off Stack
-----------
PUTDOWN(A)
CLEAR(D)
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::PUTDOWN(A)
-----------
CLEAR(D)
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,B)
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,B) True pushed off Stack
-----------
ON(D,B)^CLEAR(D)^ARMEMPTY
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,B)^CLEAR(D)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(D)
ON(D,B)
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ON(D,B)
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,B)
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,B) True pushed off Stack
-----------
UNSTACK(D,B)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::UNSTACK(D,B)
-----------
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(D)^CLEAR(C) Compound Split Before Re-entry
-----------
CLEAR(C)
HOLDING(D)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) True pushed off Stack
-----------
HOLDING(D)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(D) True pushed off Stack
-----------
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::STACK(D,C)
-----------
ON(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(C,B) False Replaced with action
-----------
CLEAR(B)
HOLDING(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(B) True pushed off Stack
-----------
HOLDING(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(C) False Replaced with action
-----------
ARMEMPTY
CLEAR(C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) False Replaced with action
-----------
ARMEMPTY
CLEAR(D)
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,C) True pushed off Stack
-----------
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,C)^CLEAR(D)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(D)
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(D,C) True pushed off Stack
-----------
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::UNSTACK(D,C)
-----------
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(C) True pushed off Stack
-----------
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(C)^CLEAR(C)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY False Replaced with action
-----------
HOLDING(D)
HOLDING(D)
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(D) True pushed off Stack
-----------
HOLDING(D)
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(D) True pushed off Stack
-----------
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::PUTDOWN(D)
-----------
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) True pushed off Stack
-----------
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(C) True pushed off Stack
-----------
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::PICKUP(C)
-----------
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(C)^CLEAR(B) Compound Split Before Re-entry
-----------
CLEAR(B)
HOLDING(C)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(B) True pushed off Stack
-----------
HOLDING(C)
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(C) True pushed off Stack
-----------
STACK(C,B)
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::STACK(C,B)
-----------
ON(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(B,A) False Replaced with action
-----------
CLEAR(A)
HOLDING(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(A) True pushed off Stack
-----------
HOLDING(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(B) False Replaced with action
-----------
ARMEMPTY
CLEAR(B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(B) False Replaced with action
-----------
ARMEMPTY
CLEAR(C)
ON(C,B)
ON(C,B)^CLEAR(C)^ARMEMPTY
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(C)
ON(C,B)
ON(C,B)^CLEAR(C)^ARMEMPTY
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) True pushed off Stack
-----------
ON(C,B)
ON(C,B)^CLEAR(C)^ARMEMPTY
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(C,B) True pushed off Stack
-----------
ON(C,B)^CLEAR(C)^ARMEMPTY
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(C,B)^CLEAR(C)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(C)
ON(C,B)
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(C)
ON(C,B)
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(C) True pushed off Stack
-----------
ON(C,B)
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ON(C,B) True pushed off Stack
-----------
UNSTACK(C,B)
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::UNSTACK(C,B)
-----------
ONTABLE(B)
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(B) True pushed off Stack
-----------
ONTABLE(B)^CLEAR(B)^ARMEMPTY
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(B)^CLEAR(B)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(B)
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ARMEMPTY False Replaced with action
-----------
HOLDING(C)
HOLDING(C)
PUTDOWN(C)
CLEAR(B)
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(C) True pushed off Stack
-----------
HOLDING(C)
PUTDOWN(C)
CLEAR(B)
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(C) True pushed off Stack
-----------
PUTDOWN(C)
CLEAR(B)
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::PUTDOWN(C)
-----------
CLEAR(B)
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(B) True pushed off Stack
-----------
ONTABLE(B)
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(B) True pushed off Stack
-----------
PICKUP(B)
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::PICKUP(B)
-----------
HOLDING(B)^CLEAR(A)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(B)^CLEAR(A) Compound Split Before Re-entry
-----------
CLEAR(A)
HOLDING(B)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
CLEAR(A) True pushed off Stack
-----------
HOLDING(B)
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
HOLDING(B) True pushed off Stack
-----------
STACK(B,A)
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
Action Performed  :::::STACK(B,A)
-----------
ONTABLE(A)
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(A) True pushed off Stack
-----------
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D)
-----------
ONTABLE(A) ^ ON(B,A) ^ ON(C,B) ^ ON(D,C) ^ ARMEMPTY ^ CLEAR(D) Compound Split Before Re-entry
-----------
CLEAR(D)
ARMEMPTY
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(D) True pushed off Stack
-----------
ARMEMPTY
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
ON(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ON(D,C) False Replaced with action
-----------
CLEAR(C)
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(C) True pushed off Stack
-----------
HOLDING(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(D) False Replaced with action
-----------
ARMEMPTY
CLEAR(D)
ONTABLE(D)
ONTABLE(D)^CLEAR(D)^ARMEMPTY
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ONTABLE(D)
ONTABLE(D)^CLEAR(D)^ARMEMPTY
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(D) True pushed off Stack
-----------
ONTABLE(D)
ONTABLE(D)^CLEAR(D)^ARMEMPTY
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(D) True pushed off Stack
-----------
ONTABLE(D)^CLEAR(D)^ARMEMPTY
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(D)^CLEAR(D)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(D)
ONTABLE(D)
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ONTABLE(D)
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(D) True pushed off Stack
-----------
ONTABLE(D)
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(D) True pushed off Stack
-----------
PICKUP(D)
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::PICKUP(D)
-----------
HOLDING(D)^CLEAR(C)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(D)^CLEAR(C) Compound Split Before Re-entry
-----------
CLEAR(C)
HOLDING(D)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(C) True pushed off Stack
-----------
HOLDING(D)
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(D) True pushed off Stack
-----------
STACK(D,C)
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::STACK(D,C)
-----------
ON(C,B)
ON(B,A)
ONTABLE(A)
-----------
ON(C,B) False Replaced with action
-----------
CLEAR(B)
HOLDING(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(B) True pushed off Stack
-----------
HOLDING(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(C) False Replaced with action
-----------
ARMEMPTY
CLEAR(C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(C) False Replaced with action
-----------
ARMEMPTY
CLEAR(D)
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,C)
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ON(D,C) True pushed off Stack
-----------
ON(D,C)^CLEAR(D)^ARMEMPTY
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ON(D,C)^CLEAR(D)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(D)
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY True pushed off Stack
-----------
CLEAR(D)
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(D) True pushed off Stack
-----------
ON(D,C)
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ON(D,C) True pushed off Stack
-----------
UNSTACK(D,C)
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::UNSTACK(D,C)
-----------
ONTABLE(C)
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(C) True pushed off Stack
-----------
ONTABLE(C)^CLEAR(C)^ARMEMPTY
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(C)^CLEAR(C)^ARMEMPTY Compound Split Before Re-entry
-----------
ARMEMPTY
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ARMEMPTY False Replaced with action
-----------
HOLDING(D)
HOLDING(D)
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(D) True pushed off Stack
-----------
HOLDING(D)
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(D) True pushed off Stack
-----------
PUTDOWN(D)
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::PUTDOWN(D)
-----------
CLEAR(C)
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(C) True pushed off Stack
-----------
ONTABLE(C)
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
ONTABLE(C) True pushed off Stack
-----------
PICKUP(C)
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::PICKUP(C)
-----------
HOLDING(C)^CLEAR(B)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(C)^CLEAR(B) Compound Split Before Re-entry
-----------
CLEAR(B)
HOLDING(C)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
CLEAR(B) True pushed off Stack
-----------
HOLDING(C)
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
HOLDING(C) True pushed off Stack
-----------
STACK(C,B)
ON(B,A)
ONTABLE(A)
-----------
Action Performed  :::::STACK(C,B)
-----------
ON(B,A)
ONTABLE(A)
-----------
ON(B,A) True pushed off Stack
-----------
ONTABLE(A)
-----------
ONTABLE(A) True pushed off Stack
--Steps to perfrom--
UNSTACK(A,C)
PUTDOWN(A)
UNSTACK(D,B)
STACK(D,C)
UNSTACK(D,C)
PUTDOWN(D)
PICKUP(C)
STACK(C,B)
UNSTACK(C,B)
PUTDOWN(C)
PICKUP(B)
STACK(B,A)
PICKUP(D)
STACK(D,C)
UNSTACK(D,C)
PUTDOWN(D)
PICKUP(C)
STACK(C,B)
vrushil@vrushil:~/AIR$ 

*/
