// ---------------Assignment No.4----------------
//Title:- Write C++ program to draw inscribed and circumscribed circles in triangle using circle drawing and line drawing algo. 

#include<iostream>
#include<stdlib.h>
#include<graphics.h> //header file for switching text to graphics mode  
#include<math.h>

using namespace std;

using namespace std;
class Line
{
  int s1,s2;
  public:
     void dda(int,int,int,int);
     int sign(float);
     void circle_bres(int x,int y,int rad);
     void display(int x1,int y1,int x,int y);
    
};



void Line::dda(int x1,int y1,int x2,int y2)   //DDA Algorithm
{
   
   int i,length,dx,dy;
   float x,y,xinc,yinc,temp1;

//Step 2: find dx and dy  
   dx=abs(x2-x1);
   dy=abs(y2-y1);

//Step 3:decide in which direction to move 
  if(dx>=dy)
   length=dx;
  else
   length=dy;

//Step 4: find increment value for x and y
  xinc=(float)(x2-x1)/length;
  yinc=(float)(y2-y1)/length;
     s1=sign(xinc);
     s2=sign(yinc);
     

//Step 5: Plot first pixel   
  x=x1+(0.5*s1);
  y=y1+(0.5*s2);;
  putpixel(x,y,WHITE); //plot first pixel
 
//Step 6: 
  for(i=1;i<=length;i++)
   {  
      x=x+xinc;
      y=y+yinc;
      putpixel(x,y,WHITE);
   
   }

}

//Sign function
int Line::sign(float temp)  
{
  if(temp==0) return 0;
  else if(temp>0) return 1;
  else return -1;
}


int main()
{
    int rad,x,y;
    Line s;
    int x1,y1;
    char a;  
    int gd=DETECT,gm;
    initgraph(&gd,&gm,NULL);
     
    cout<<"Enter Center co-ordinates for circle: ";
    cin>>x>>y;
    cout<<"Enter radius of circle: ";
    cin>>rad;
    x1=0;
    y1=rad;
    do
     {
       s.circle_bres(x,y,rad);
       s.dda(x+x1,y-y1,185,150);
       s.dda(185,150,12,150);
       s.dda(12,150,x+x1,y-y1);
       s.circle_bres(x,y,rad/2);
       cout<<"\n\ndo u want to continue(y/n)::";      
       cin>>a;
    }while(a=='y');
   }

void  Line::circle_bres(int x,int y,int r)
{
   float dp;   //intialize decision parameter
   Line s;
   int x1,y1;
   x1=0;
   y1=r;
   dp=3-2*r;
       
    while(x1<=y1)
     {
       if(dp<=0)
        dp+=(4*x1)+6;
       else
        { 
          dp+=4*(x1-y1)+10;
          y1--;
        }
        x1++;
        s.display(x1,y1,x,y);
     }
    
}


void  Line::display(int x1,int y1,int x,int y)
 {
    putpixel(x+x1,y+y1,WHITE);  //plotting pixel
    putpixel(x+y1,y+x1,WHITE);  
    putpixel(x-y1,y+x1,WHITE);
    putpixel(x+x1,y-y1,WHITE);
    putpixel(x-x1,y-y1,WHITE);
    putpixel(x-y1,y-x1,WHITE);
    putpixel(x+y1,y-x1,WHITE);
    putpixel(x-x1,y+y1,WHITE);
 }

