//#include<conio.h>
#include<graphics.h>
//#include<dos.h>
#include<iostream>

using namespace std;

void floodFill(int x, int y, int old, int fill)
{
	int current;
	current=getpixel(x,y);
	if(current==old)
	{
		putpixel(x,y,fill);
		delay(5);
		floodFill(x+1,y,old,fill);
		floodFill(x-1,y,old,fill);
		floodFill(x, y+1,old,fill);
		floodFill(x,y-1,old,fill);
	}
}

int main()
{
		int x,y,o=0,x1,y1,x2,y2;
		//clrscr();
		int gDriver=DETECT,gmode;
		initgraph(&gDriver,&gmode, NULL);
                cout<<"Enter the coordinates of rectangle:";
                cin>>x1>>y1>>x2>>y2;
		rectangle(x1,y1,x2,y2);
		x=(x1+x2)/2;
		y=(y1+y2)/2;
		floodFill(x,y,o,4);
		//getch();
                delay(500000);
		closegraph();
                return 0;
}
