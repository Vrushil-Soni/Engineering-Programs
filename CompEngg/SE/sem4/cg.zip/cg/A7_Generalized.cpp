#include<iostream>
#include<math.h>
#include<graphics.h>

using namespace std;

class line1
{
public:
    void dda(int,int,int,int);
    void circle_bres(int x,int y,int rad);
};

void line1::dda(int x1,int y1,int x2,int y2)
{
    int i, length ,dx,dy;
    float x,y,xinc,yinc;
    dx=abs(x2-x1);
    dy=abs(y2-y1);
    if(dx>=dy)
    {
        length=dx;
    }
    else
    {
        length=dy;
    }
    xinc=(float)(x2-x1)/length;
    yinc=(float)(y2-y1)/length;
    x=x1+0.5;
    y=y1+0.5;
    putpixel(x,y,WHITE);

    for(i=1;i<=length;i++)
    {
        x=x+xinc;
        y=y+yinc;
        putpixel(x,y,WHITE);
    }
}

void line1::circle_bres(int x1,int y1,int r)
{
    int x,y,p;
    x=0;
    y=r;
    p=3-(2*r);

    while(x<=y)
    {
        putpixel(x1+x,y1+y,WHITE);
        putpixel(x1-x,y1+y,WHITE);
        putpixel(x1+x,y1-y,WHITE);
        putpixel(x1-x,y1-y,WHITE);
        putpixel(x1+y,y1+x,WHITE);
        putpixel(x1+y,y1-x,WHITE);
        putpixel(x1-y,y1+x,WHITE);
        putpixel(x1-y,y1-x,WHITE);
        x=x+1;

        if(p<0)
        {
            p=p+4*(x)+6;
        }
        else
        {
            p=p+4*(x-y)+10;
            y=y-1;
        }
    }
}
int main()
{
    int rad,xc,yc,x1,y1,r,ir,x4,y4,x5,y5,m,n;
    int p;
    int gd=DETECT,gm;
     line1 s1;
    initgraph(&gd,&gm,NULL);

    cout<<"Enter Circle Co-ordinate";
    cin>>xc>>yc;
    cout<<"Radius of Cirle";
    cin>>rad;
    x1=0;
    y1=rad;

    s1.circle_bres(xc,yc,rad);



    r=rad;
    ir=rad/2;
    m=r*r;
    n= ir*ir;

   p=sqrt(m-n);
   x4=xc+p;
   y4=r+ir;
   x5=xc-p;
   y5=r+ir;


    s1.dda(xc+x1,yc-y1,x4,y4);
    s1.dda(x4,y4,x5,y5);
    s1.dda(x5,y5,xc+x1,yc-y1);
    s1.circle_bres(xc,yc,ir);
    delay(50000);
    return 0;

}
