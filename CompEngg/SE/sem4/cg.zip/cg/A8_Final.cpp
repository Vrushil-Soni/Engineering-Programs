// ---------------Assignment No.4----------------
//Title:- Write C++ program to draw following pattern using any line drawing algo. 

#include<iostream>
#include<stdlib.h>
#include<graphics.h> //header file for switching text to graphics mode  
#include<math.h>

using namespace std;
class Line
{
  int s1,s2;
  public:
     void dda(int,int,int,int);
     int sign(float);
    
};



void Line::dda(int x1,int y1,int x2,int y2)   //DDA Algorithm
{
   
   int i,length,dx,dy;
   float x,y,xinc,yinc,temp1;

//Step 2: find dx and dy  
   dx=abs(x2-x1);
   dy=abs(y2-y1);

//Step 3:decide in which direction to move 
  if(dx>=dy)
   length=dx;
  else
   length=dy;

//Step 4: find increment value for x and y
  xinc=(float)(x2-x1)/length;
  yinc=(float)(y2-y1)/length;
     s1=sign(xinc);
     s2=sign(yinc);
     //cout<<"\n S1="<<s1<<"S2="<<s2;

//Step 5: Plot first pixel   
  x=x1+(0.5*s1);
  y=y1+(0.5*s2);;
  putpixel(x,y,WHITE); //plot first pixel
    //cout<<"Initial X="<<x<<"\n";
   // cout<<"Initial Y="<<y<<"\n";  

//Step 6: 
  for(i=1;i<=length;i++)
   {  
      x=x+xinc;
      y=y+yinc;
      putpixel(x,y,WHITE);
      //cout<<"X="<<x;
      //cout<<"Y="<<y<<"\n";  
   }

}

//Sign function
int Line::sign(float temp)  
{
  if(temp==0) return 0;
  else if(temp>0) return 1;
  else return -1;
}


int main()
{
    Line s; char a;
    int gd=DETECT,gm;
    initgraph(&gd,&gm,NULL);
    int x1,x2,y1,y2,x3,y3,x4,y4, xmid,ymid,x1mid,y1mid,x2mid,y2mid;
    do
    {
       //Step1: read end points of line to draw pattern
      cout<<"Enter the X1 and Y1 co-ordiates::";   cin>>x1>>y1;  
      cout<<"Enter the X2 and Y2 co-ordiates::";   cin>>x2>>y2;
      cout<<"x1="<<x1<<""<<"x2="<<x2;
      cout<<"\n"<<"y1="<<y1<<" "<<"y2"<<y2;
     s.dda(x1,y1,x2,y1);
     s.dda(x2,y1,x2,y2);
     s.dda(x2,y2,x1,y2);
     s.dda(x1,y2,x1,y1);
     xmid=x1+abs(x2-x1)/2;

     ymid=y1+abs(y2-y1)/2;

     x1mid=x1+abs(x1-xmid)/2;

     y1mid=y1+abs(y1-ymid)/2;

     x2mid=xmid+abs(xmid-x2)/2;

     y2mid=ymid+abs(ymid-y2)/2;


     
     s.dda(xmid,y1,x2,ymid);
     s.dda(x2,ymid,xmid,y2);
     s.dda(xmid,y2,x1,ymid);
     s.dda(x1,ymid,xmid,y1);
     
     s.dda(x1mid,y1mid,x2mid,y1mid);
     s.dda(x2mid,y1mid,x2mid,y2mid);
     s.dda(x2mid,y2mid,x1mid,y2mid);
     s.dda(x1mid,y2mid,x1mid,y1mid);
     cout<<"\n\ndo u want to continue(y/n)::";      
     cin>>a;
    }while(a=='y');

}


