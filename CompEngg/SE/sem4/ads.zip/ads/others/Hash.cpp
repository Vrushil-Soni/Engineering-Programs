#include<iostream>
using namespace std;
#define max 10

class hashtab
{
public:
    class dict
    {
    public:
        int k;
        int val;
    dict()
    {
        for(int i=0;i<max;i++)
        {
            k=-1;
            val=0;
        }
    }
    }d[max];
    int hash_div_method(int);
    void insert(int,int,int);
    void display();
    int search(int);
    void Delete(int);
};

int hashtab::hash_div_method(int num)
{
    int hkey;
    hkey=num%max;
    return hkey;
}

void hashtab::insert(int index,int value,int key)
{
    int i;
    if(d[index].val==0)
    {
        d[index].k=key;
        d[index].val=value;
    }
    else
    for(int i=index+1;i<max;i++)
    {
        if(d[i].val==0)
        {
            d[index].k=i;
            d[i].k=-1;
            d[i].val=value;
            break;
        }
    }
    if(i==max-1)
    {
        for(i=0;i<index;i++)
        {
            if(d[i].val==0)
            {
		d[i-1].k=i;
                d[i].k=-1;
                d[i].val=value;
                break;
            }
        }
    }
    if(i==index)
    cout<<"\nHashtable is full\n";
}

void hashtab::display()
{
    cout<<"\nNO.\tVALUE\tKEY"<<endl;
    for(int i=0;i<max;i++)
    cout<<"\n"<<i<<"\t"<<d[i].val<<"\t"<<d[i].k;
}

int hashtab::search(int search_key)
{
    int j;
    int i=hash_div_method(search_key);
    if(d[i].val==search_key)
    {
        cout<<"\n"<<d[i].k<<"\t"<<d[i].val;
        return i;
    }
    for(j=i+1;j<max;j++)
    {
        if(d[j].val==search_key)
        {
            cout<<"\n"<<d[j].k<<"\t"<<d[j].val;
            return j;
        }
    }
    for(j=0;j<i;j++)
    {
        if(d[j].val==search_key)
        {
            cout<<"\n"<<d[j].k<<"\t"<<d[j].val;
            return j;
        }
    }
    cout<<"\nKey not found\n";
    return -1;
}

void hashtab::Delete(int key)
{
    int index=search(key);
    d[index].k=-1;
    d[index].val=0;
    cout<<"\n record deleted\n";
}

int main()
{
    char ans;
    int ch;
    hashtab h;
    int hkey1,a,b,c,d,index1;
    cout<<"\n***********HASHING***********\n";
    do
    {
        cout<<"\n1.Insert Element\n2.Display Hash Table\n3.Search Element\n4.Delete Element\nEnter your choice:";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter value and key to be inserted:";
                cin>>a>>b;
                hkey1=h.hash_div_method(a);
                h.insert(hkey1,a,b);
                break;
            case 2:
                h.display();
                break;
            case 3:
                cout<<"\nEnter key to be searched:";
                cin>>c;
                index1=h.search(c);
                break;
            case 4:
                cout<<"\nEnter key to be deleted:";
                cin>>d;
                h.Delete(d);
                break;
            default:
                cout<<"\nInvalid choice"<<endl;
                break;
        }
        cout<<"\nDo you want to continue?(y/n);"<<endl;
        cin>>ans;
    }while(ans=='y'||ans=='Y');
    return 0;
}

