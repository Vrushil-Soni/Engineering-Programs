/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Smita
 */
import p2.*;
import java.io.*;
public class PkgDemo {
    public static void main(String args[]) throws IOException{
        FixedStack a = new FixedStack();
        String ans;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        do{
        System.out.println("Enter value to be pushed: ");
        int x = Integer.parseInt(br.readLine());
        a.pushOperation(x);
        System.out.println("Want to push more elements: ");
        ans = br.readLine();
        }while(ans.equals("y"));
        a.popOperation();
    }
}
