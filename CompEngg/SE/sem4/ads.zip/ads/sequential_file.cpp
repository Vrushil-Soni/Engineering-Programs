/*
 * sequential_file.cpp
 *
 *  Created on: 26-Mar-2018
 *      Author: root
 */


//Program by Vrushil Soni

//Sequential file


#include<iostream>

#include<fstream>

#include<string.h>

using namespace std;


class database

{

public:

	int rollno;

	char name[15];

	char address[10];

	char year[5];

};


class student

{

	database B;

public:

	fstream b;


	void search()

	{

		char name[10];

		ifstream p;

		p.open("database.txt");

		cout<<"\nEnter the name to be searched:\n";

		cin>>name;

		while(p.read((char*)&B,sizeof(B)))

		{

			if(strcmp(name,B.name)==0)

			{

				cout<<"\nThe name is present in table...!!\n";

				cout<<"\nName:"<<B.name;

				cout<<"\nRollNo:"<<B.rollno;

				cout<<"\nAddress(City):"<<B.address;

				cout<<"\nYear:"<<B.year;

				p.close();

				return;

			}

		}

		cout<<"\nName not Present..\n";

		p.close();

	}


	void add()

	{

		ofstream fout;

		fout.open("database.txt",ios::app);

		cout<<"\nEnter The Name:";

		cin>>B.name;

		cout<<"\nEnter The RollNO:";

		cin>>B.rollno;

		cout<<"\nEnter The Address(City):";

		cin>>B.address;

		cout<<"\nEnter The Year:";

		cin>>B.year;

		fout.write((char*)&B,sizeof(B));

		fout.close();

	}


	void Delete()

	{

		fstream out,in;

		char name[10];

		in.open("database.txt",ios::in);

		out.open("temp.txt",ios::in|ios::out);

		cout<<"\nEnter the symbol to be deleted:";

		cin>>name;

		while(in.read((char*)&B,sizeof(B)))

		{

			if(strcmp(name,B.name)!=0)

			{

				out.write((char*)&B,sizeof(B));

			}

		}

		in.close();

		out.close();

		remove("database.txt");

		rename("temp.text","database.txt");

	}

};


int main()

{

	student s;

	int ch1;

	char ch2='y';

	cout<<"\nWelcome to the student database\n";

	do

	{

		cout<<"\n1.Search\n2.Delete\n3.Add\nEnter your choice:";

		cin>>ch1;

		switch(ch1)

		{

		case 1:

			s.search();

			break;

		case 2:

			s.Delete();

			break;

		case 3:

			s.add();

			break;

		default:

			cout<<"\nInvalid choice\n";

			break;

		}

		cout<<"\nDo you want to continue?(y/n):";

		cin>>ch2;

	}while(ch2=='y'||ch2=='Y');

	return 0;

}




//output


/*

vrushil@vrushil:~$ cd sequentialfile/

vrushil@vrushil:~/sequentialfile$ g++ sequential_file.cpp

vrushil@vrushil:~/sequentialfile$ ./a.out


Welcome to the student database


1.Search

2.Delete

3.Add

Enter your choice:3


Enter The Name:Vrushil


Enter The RollNO:37


Enter The Address(City):pune


Enter The Year:1999


Do you want to continue?(y/n):y


1.Search

2.Delete

3.Add

Enter your choice:3


Enter The Name:bhargav


Enter The RollNO:15


Enter The Address(City):panshet


Enter The Year:1998


Do you want to continue?(y/n):y


1.Search

2.Delete

3.Add

Enter your choice:1


Enter the name to be searched:
vrushil


Name not Present..


Do you want to continue?(y/n):y


1.Search

2.Delete

3.Add

Enter your choice:1


Enter the name to be searched:
Vrushil


The name is present in table...!!


Name:Vrushil

RollNo:37

Address(City):pune

Year:1999

Do you want to continue?(y/n):y


1.Search

2.Delete

3.Add

Enter your choice:2


Enter the symbol to be deleted:bhargav


Do you want to continue?(y/n):y


1.Search

2.Delete

3.Add

Enter your choice:1


Enter the name to be searched:
bhargav


Name not Present..


Do you want to continue?(y/n):n

vrushil@vrushil:~/sequentialfile$ 


*/
