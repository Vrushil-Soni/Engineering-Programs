//heap sort

//vrushil soni
 

#include<iostream>

using namespace std;

#define max 10

class heap

{

	int marks[max];

   	int n;

public:

  	 heap()

	{

        	n=0;

        	for(int i=0;i<max;i++)

		{

	            marks[i]=0;

	        }

	}

    	void insert(int num);

    	void makeheap();

    	void heapsort();

    	void display();

    	void display_max_min_marks();

};

 
void heap::insert(int num)

{

    if(n<max)

	{

	        marks[n]=num;

	        n++;

	}

    else

        cout<<"\n Array is full...";

}

 
void heap::makeheap()

{

	for(int i=1;i<n;i++)

	{

	        int val=marks[i];

	        int j=i;

	        int f=(j-1)/2;

	        while(j>0 && marks[f]<val)

		{

	            marks[j]=marks[f];

	            j=f;

	            f=(j-1)/2;

	        }

	        marks[j]=val;

	    }

}

 
void heap::heapsort()

{

	for(int i=n-1;i>0;i--)

	{

	        int temp=marks[i];

	        marks[i]=marks[0];

	        int k=0;

	        int j;

	        if(i==1)

		{

        	    j=-1;

        	}

        	else

		{

			j=1;

	        }

	        if(i>2 && marks[2]>marks[1])

	            j=2;

        	while(j>=0 && temp<marks[j])

		{

        	    marks[k]=marks[j];

	            k=j;

	            j=2*k+1;

	            if(j+1 <= i-1 && marks[j]<marks[j+1])

	                j++;

	            if(j>i-1)

	                j=-1;

	        }

	        marks[k]=temp;

	 }

}

 
void heap::display()

{

    for(int i=0;i<n;i++)

	{

	        cout<<marks[i]<<"\t";

	}

}

 
void heap::display_max_min_marks()

{

    cout<<"\n The maximum marks: "<<marks[n-1];

    cout<<"\n The minimum marks: "<<marks[0]<<endl;

}

 
int main()

{

    heap h;

    int mrks;

    char ans='y';

    do

	{

	        cout<<"\n Enter marks: ";

	        cin>>mrks;

	        h.insert(mrks);

	        cout<<"\n Want to enter more marks: ";

	        cin>>ans;

	}while(ans=='y' || ans=='Y');

    cout<<"\n Marks obtained by students are "<<endl;

    h.display();

    cout<<endl;

    h.makeheap();

    h.heapsort();

    cout<<"\n Marks in sorted order "<<endl;

    h.display();

    cout<<endl;

    h.display_max_min_marks();

	return 0;

}




//output



/*

vrushil@vrushil:~$ g++ heapsorting.cpp

vrushil@vrushil:~$ ./a.out


Enter marks: 11

 
Want to enter more marks: y


Enter marks: 15


Want to enter more marks: y


Enter marks: 23

 
Want to enter more marks: y


Enter marks: 17

 
Want to enter more marks: y

 
Enter marks: 27

 
Want to enter more marks: y

 
Enter marks: 26

 
Want to enter more marks: y

 
Enter marks: 19

 
Want to enter more marks: y

 
Enter marks: 14

 
Want to enter more marks: y

 
Enter marks: 20

 
Want to enter more marks: y

 
Enter marks: 22

 
Want to enter more marks: y

 
Enter marks: 25

 
Array is full...
 
Want to enter more marks: n

 
Marks obtained by students are 

11	15	23	17	27	26	19	14	20	22	

 
Marks in sorted order 

11	14	15	17	19	20	22	23	26	27	

 
The maximum marks: 27
 
The minimum marks: 11

vrushil@vrushil:~$ 


*/
