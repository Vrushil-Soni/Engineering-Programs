/*
 * ads8.cpp
 *
 *  Created on: 23-Mar-2018
 *      Author: root
 */

//SYMBOL TABLE
//Program by vrushil Soni
#include<iostream>
#include<fstream>
//#include<conio.h>
#include<stdio.h>
#include<string.h>
using namespace std;

class intermediate
{
public:
	int addr;
	char label[10];
	char mnem[10];
	char op[10];
};

class sym
{
public:
	char symbol[10];
	int addr;
};

class symbol
{
	sym s;
	intermediate res;
public:
	void create()
	{
		fstream p1;
		ifstream s1;
		p1.open("symbol.txt",ios::out);
		s1.open ("inter.txt");
		while(s1>>res.addr)
		{
			s1>>res.label>>res.mnem>>res.op;
			if(strcmp(res.label,"NULL")!=0)
			{
				strcpy(s.symbol,res.label);
				s.addr=res.addr;
				p1.write((char*)&s,sizeof(s));
			}
		}
		s1.close();
	}

	void search()
	{
		char name[10];
		ifstream p;
		p.open("symbol.txt");
		cout<<"\nEnter the name to be searched:";
		cin>>name;
		while(p.read((char*)&s,sizeof(s)))
		{
			if(strcmp(name,s.symbol)==0)
			{
				cout<<"\n The name is present in the table";
				cout<<s.symbol<<":"<<s.addr;
				p.close();
				return;
			}
		}
		cout<<"\n Name not Present";
		p.close();
	}

	void modify()
	{
		char name[10];
		fstream p;
		p.open("symbol.txt",ios::in|ios::out);
		int len=sizeof(s);
		cout<<"\n Enter label:";
		cin>>name;
		p.seekg(0,ios::beg);
		while(p.read((char*)&s,sizeof(s)))
		{
			if(strcmp(name,s.symbol)==0)
			{
				cout<<"\nThe name is present in table";
				cout<<"\nEnter new address:";
				cin>>s.addr;
				int pos=p.tellg();
				int offset=pos-len;
				p.seekp(offset,ios::beg);
				p.write((char*)&s,sizeof(s));
				return;
			}
		}
		cout<<"\nName not present";
	}

	void insert()
	{
		ofstream fout;
		fout.open("symbol.txt",ios::app);
		cout<<"\nEnter the Symbols And its address:";
		cin>>s.symbol;
		cin>>s.addr;
		fout.write((char*)&s,sizeof(s));
		fout.close();
	}

	void Delete()
	{
		fstream in;
		fstream out;
		char name[10];
		in.open("symbol.txt",ios::in);
		out.open("temp.txt",ios::in|ios::out);
		cout<<"\nEnter the symbol to be deleted:";
		cin>>name;
		while(in.read((char*)&s,sizeof(s)))
		{
			if(strcmp(name,s.symbol)!=0)
			{
				out.write((char*)&s,sizeof(s));
			}
		}
		in.close();
		out.close();
		remove("symbol.txt");
		rename("temp.txt","symbol.txt");
	}
};

int main()
{
	symbol sy;
	int ch;
	char ans='y';
	do
	{
		cout<<"\n          *******Menu********";
		cout<<"\n1.create\n2.search\n3.modify\n4.delete\n5.Insert new symbol\n";
		cout<<"\nEnter your choice:";
		cin>>ch;
		switch(ch)
		{
		case 1:
			sy.create();
			break;
		case 2:
			sy.search();
			break;
		case 3:
			sy.modify();
			break;
		case 4:
			sy.Delete();
			break;
		case 5:
			sy.insert();
			break;
		default:
			cout<<"\nInvalid choice\n";
			break;
		}
		cout<<"\nWant to perform more operations:";
		cin>>ans;
	}while(ans=='y'||ans=='Y');
	return 0;
}

//output

/*
vrushil@vrushil:~/symboltable$ g++ ads8.cpp
vrushil@vrushil:~/symboltable$ ./a.out

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:5

Enter the Symbols And its address:vrushil
10

Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:5

Enter the Symbols And its address:nakshatra
20

Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:5

Enter the Symbols And its address:bhargav
30

Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:2

Enter the name to be searched:vrushil

 The name is present in the tablevrushil:10
Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:3

 Enter label:bhargav

The name is present in table
Enter new address:40

Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:2

Enter the name to be searched:bhargav

 The name is present in the tablebhargav:40
Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:4

Enter the symbol to be deleted:bhargav

Want to perform more operations:y

          *******Menu********
1.create
2.search
3.modify
4.delete
5.Insert new symbol

Enter your choice:2

Enter the name to be searched:bhargav

 Name not Present
Want to perform more operations:n
vrushil@vrushil:~/symboltable$ 

*/
