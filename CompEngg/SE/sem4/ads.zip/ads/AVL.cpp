/*
 * AVL.cpp
 *
 *  Created on: 13-Mar-2018
 *      Author: root
 */

//Program by Vrushil Soni

//Program to implement AVL Tree

#include<iostream>

#include<string.h>

using namespace std;
class node

{

public:
	
string data;
	
string mean;
	
node *left;
	
node *right;
	
int height
;

};

class dict

{

public:
	
node *root;
	
dict()
	
{
		
root=NULL;
	
}
	
void create();
	
node* insert(node *,node *);
	
void inorder(node *);
	
void descend(node*);
	
void search(node *,string);
	
void modify(node*,string);
	
node* minval(node*);
	
node* delnode(node*,string);
	
int getbalance(node *N);
	
node* leftrotate(node *x);
	
node* rightrotate(node* y);
	
int height(node *N);

};


int dict::getbalance(node *N)

{
	
if(N==NULL)
		
return 0;
	
return height(N->left)-height(N->right);

}


void dict::create()

{
	
node *temp=new node;
	
string a,b;
	
cout<<"\nEnter a word\n";
	
//getline(cin,a);
	
cin>>temp->data;
	
cout<<"\nEnter its meaning\n";
	
//getline(cin,b);
	
cin>>temp->mean;
	
temp->left=temp->right=NULL;
	
temp->height=1;
	
if(root==NULL)
		
root=temp;
	
else
		
root=insert(root,temp);

}


int dict::height(node *N)

{
	
if (N==NULL)
		
return 0;
	
else
		
return N->height;

}


node* dict::rightrotate(node *y)

{
	
node *x=y->left;
	
node *T2=x->right;
	
x->right=y;
	
y->left=T2;
	
y->height=max(height(y->left),height(y->right))+1;
	
x->height=max(height(x->left),height(x->right))+1;
	
return x;

}


node* dict::leftrotate(node *x)

{
	
node *y=x->right;
	
node *T2=y->left;
	
y->left=x;
	
x->right=T2;
	
x->height=max(height(x->left),height(x->right))+1;
	
y->height=max(height(y->left),height(y->right))+1;
	
return y;

}


node* dict::insert(node *root,node *temp)

{
	
if(temp->data<root->data)
	
{
		
if(root->left==NULL)
			
root->left=temp;
		
else
			
root->left=insert(root->left,temp);
	
}
	
else
	
{
		
if(root->right==NULL)
			
root->right=temp;
		
else
			
root->right=insert(root->right,temp);
	
}
	
root->height=1+max(height(root->left),height(root->right));
	
int balance=getbalance(root);
	
if(balance>1&&temp->data<root->left->data)
		
return rightrotate(root);
	
if(balance<-1 && temp->data > root->right->data)
		
return leftrotate(root);
	
if(balance>1&&temp->data>root->left->data)
	
{
		
root->left=leftrotate(root->left);
		
return rightrotate(root);
	
}
	
if(balance<-1&&temp->data<root->right->data)
	
{
		
root->right=rightrotate(root->right);
		
return leftrotate(root);
	
}
	
return root;

}


void dict::inorder(node *temp)

{
	
if(temp!=NULL)
	
{
		
inorder(temp->left);
		
cout<<temp->data<<endl;
		
cout<<"Meaning:"<<temp->mean<<endl;
		
inorder(temp->right);
	
}

}


void dict::descend(node *temp)

{
	
if(temp!=NULL)
	
{
		
descend(temp->right);
		
cout<<temp->data<<endl;
		
cout<<"Meaning:"<<temp->mean<<endl;
		
descend(temp->left);
	
}

}


void dict::search(node *root,string str_key)

{
	
if(str_key.compare(root->data)<0)
	
{
		
if(root->left==NULL)
			
cout<<"Word not found"<<endl;
		
else
			
search(root->left,str_key);
	
}
	
else if(str_key.compare(root->data)>0)
	
{
		
if(root->right==NULL)
			
cout<<"Word not found"<<endl;
		
else
			
search(root->right,str_key);
	
}
	
else
	
{
		
cout<<"\nWord:"<<root->data<<endl;
		
cout<<"Meaning:"<<root->mean<<endl;
	
}

}


void dict::modify(node*root,string str_key)

{
	
if(str_key.compare(root->data)<0)
	
{
		
if(root->left==NULL)
			
cout<<"Word not found"<<endl;
		
else modify(root->left,str_key);
	
}
	
else if(str_key.compare(root->data)>0)
	
{
		
if(root->right==NULL)
			
cout<<"Word not found"<<endl;
		
else
			
modify(root->right,str_key);
	
}
	
else
	
{
		
cout<<"\nWord:"<<root->data<<endl;
		
cout<<"Meaning:"<<root->mean<<endl;
		
cout<<"Enter new meaning:"<<endl;
		
string s;
		
getline(cin,s);
		
root->mean=s;
		
cout<<"\nWord:"<<root->data<<endl;
		
cout<<"Meaning:"<<root->mean<<endl;
	
}

}


node *dict::minval(node *root)

{
	
node*curr;
	
curr=new node;
	
curr=root;
	
while(curr->left!=NULL)
		
curr=curr->left;
	
return curr;

}


node*dict::delnode(node *root,string str_key)

{
	
if(root==NULL)
		
return root;
	
node*temp;
	
temp=new node;
	
if(str_key.compare(root->data)<0)
	
{
		
if(root->left==NULL)
			
cout<<"Word not found"<<endl;
		
else
			
root->left=delnode(root->left,str_key);

}
	
else if(str_key.compare(root->data)>0)
	
{
		
if(root->right==NULL)
			
cout<<"Word not found"<<endl;
		
else
			
root->right=delnode(root->right,str_key);
	
}
	
else
	
{
		
if(root->left==NULL||root->right==NULL)
		
{
			
temp=root->left?root->left:root->right;
			
if(temp==NULL)
			
{
				
temp=root;
				
root=NULL;
			
}
			
else
				
*root=*temp;
			
delete temp;
		
}
		
else
		
{
			
temp=minval(root->right);
			
root->data=temp->data;
			
root->right=delnode(root->right,temp->data);
		
}
	
}
	
if(root==NULL)
		
return root;
	
root->height=1+max(height(root->left),height(root->right));
	
int balance=getbalance(root);
	
if(balance>1&&getbalance(root->left)>=0)
		
return rightrotate(root);
	
if(balance>1&&getbalance(root->left)<0)
	
{
		
root->left=leftrotate(root->left);
		
return rightrotate(root);
	
}
	
if(balance<-1&&getbalance(root->right)<=0)
	
{
		
return leftrotate(root);
	
}
	
if(balance<-1&&getbalance(root->right)>0)
	
{
		
root->right=rightrotate(root->right);
		
return leftrotate(root);
	
}
	
return root;

}


int main()

{
	
dict b;
	
string key;
	
cout<<"\n*************DICTIONARY USING AVL TREE***********\n\n";
	
int choice;
	
do
	
{
		
cout<<"\n1.Create\n2.Ascending Order\n3.Descending order\n4.Search\n5.Modify\n6.Delete\nEnter your choice:";
		
cin>>choice;
		
switch(choice)
		
{
		
case 1:
			
{
				
b.create();
				
break;
			
}
		
case 2:
			
{
				
cout<<"\nAscending order:"<<endl;

b.inorder(b.root);
				
break;
			
}
		
case 3:
			
{
				
cout<<"\nDescending order:"<<endl;
				
b.descend(b.root);
				
break;
			
}
		
case 4:
			
{
				
cout<<"\nenter word you want to search"<<endl;
				
cin>>key;
				
b.search(b.root,key);
				
break;
			
}
		
case 5:
			
{
				
cout<<"\nenter word you want to modify"<<endl;
				
cin>>key;
				
b.modify(b.root,key);
				
break;
			
}
		
case 6:
			
{
				
cout<<"\nenter word you want to delete"<<endl;
				
cin>>key;
				
b.delnode(b.root,key);
				
break;
			
}
		
default:
			
{
				
cout<<"\nInvalid choice...Terminating....\n";
				
break;
			
}
		
}
	
}while(choice<7&&choice>0);
	
return 0;

}



//output


/*


*************DICTIONARY USING AVL TREE***********



1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1


Enter a word

Apple


Enter its meaning

fruit


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1


Enter a word

king


Enter its meaning

monarch


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1


Enter a word

car


Enter its meaning

vehicle


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1  


Enter a word

air


Enter its meaning

gas


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:2


Ascending order:

Apple

Meaning:fruit

air

Meaning:gas

car

Meaning:vehicle

king

Meaning:monarch


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1


Enter a word

ant


Enter its meaning

insect


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:1    


Enter a word

actor


Enter its meaning

artist


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:2


Ascending order:

Apple

Meaning:fruit

actor

Meaning:artist

air

Meaning:gas

ant

Meaning:insect

car

Meaning:vehicle

king

Meaning:monarch


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:3


Descending order:

king

Meaning:monarch

car

Meaning:vehicle

ant

Meaning:insect

air

Meaning:gas

actor

Meaning:artist

Apple

Meaning:fruit


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:4


enter word you want to search

apple

Word not found


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:4


enter word you want to search

Apple


Word:Apple

Meaning:fruit


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:5


enter word you want to modify

king


Word:king

Meaning:monarch

Enter new meaning:
duke

Word:king

Meaning:duke


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:6


enter word you want to delete

air


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:2


Ascending order:

Apple

Meaning:fruit

actor

Meaning:artist

ant

Meaning:gas

car

Meaning:vehicle

king

Meaning:duke


1.Create

2.Ascending Order

3.Descending order

4.Search

5.Modify

6.Delete

Enter your choice:7


Invalid choice...Terminating....

vrushil@vrushil:~$ 

*/
