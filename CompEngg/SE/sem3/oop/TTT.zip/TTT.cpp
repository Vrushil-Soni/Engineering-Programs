/*
NAME:- Vrushil Soni
ClASS:- S.E(c)
ROLL No:-S1612037
SUB:- OOP

         			Assignment :- MINI PROJECT(TIC-TOC-TOE)

Design and develop the Tic-Tac-Toe Game using C++

*/
#include<iostream>
using namespace std;
char square[10]={'0','1','2','3','4','5','6','7','8','9'};
char a[10],b[10];
void board()
{
	cout<<"\n\t"<<" ____"<<"_________"<<"__________"<<"______";
	cout<<"\n\t"<<"|____"<<square[1]<<"____|____"<<square[2]<<"____|____"<<square[3]<<"____|"<<endl;
	cout<<"\t"<<"|____"<<square[4]<<"____|____"<<square[5]<<"____|____"<<square[6]<<"____|"<<endl;
	cout<<"\t"<<"|____"<<square[7]<<"____|____"<<square[8]<<"____|____"<<square[9]<<"____|"<<endl;
}
int checkwin()
{
	if(square[1]==square[2]&&square[2]==square[3])
		return 1;
	else if(square[4]==square[5]&&square[5]==square[6])
		return 1;
	else if(square[7]==square[8]&&square[8]==square[9])
		return 1;
	else if(square[1]==square[4]&&square[4]==square[7])
		return 1;
	else if(square[2]==square[5]&&square[5]==square[8])
		return 1;
	else if(square[3]==square[6]&&square[6]==square[9])
		return 1;
	else if(square[1]==square[5]&&square[5]==square[9])
		return 1;
	else if(square[3]==square[5]&&square[5]==square[7])
		return 1;
	else if(square[1]!='1'&&square[2]!='2'&&square[3]!='3'&&
			square[4]!='4'&&square[5]!='5'&&square[6]!='6'&&
			square[7]!='7'&&square[8]!='8'&&square[9]!='9')
		return 0;
	else return -1;
}
int main()
{
	int choice,i;
	char mark;
	char a[10],b[10];
	int player=1;
	cout<<"\t***Welcome to tic toe Game***";
	cout<<"\nEnter player name= ";
	cin>>a>>b;
	cout<<"\n player 1= "<<a<<"\nplayer 2= "<<b;
	do
	{
		board();
		player=(player%2)?1:2;
		mark=(player==1)?'x':'o';
		cout<<"\nPlayer= "<<player;
		cout<<"\nEnter pos= ";
		cin>>choice;
		if(choice==1&&square[1]=='1')
		square[1]=mark;
		else if(choice==2&&square[2]=='2')
		square[2]=mark;
		else if(choice==3&&square[3]=='3')
		square[3]=mark;
		else if(choice==4&&square[4]=='4')
		square[4]=mark;
		else if(choice==5&&square[5]=='5')
		square[5]=mark;
		else if(choice==6&&square[6]=='6')
		square[6]=mark;
		else if(choice==7&&square[7]=='7')
		square[7]=mark;
		else if(choice==8&&square[8]=='8')
		square[8]=mark;
		else if(choice==9&&square[9]=='9')
	    square[9]=mark;
		else
		{
		cout<<"***Invalid pos***";
		--player;
		cin.ignore();//In build function
		cin.get();//In build function gives one more chance
		}
		i=checkwin();
		player++;
	}while(i==-1);
	board();
	if(i==1)
	{
		--player;
		if(player--==1)
		{
			cout<<"\n**** Player "<<a<<" win ;) ****";
			cout<<"\n**** Player "<<b<<" loss :( ****";
		}
		else
			{
			cout<<"\n**** Player "<<b<<" win ;) ****";
		    cout<<"\n**** Player "<<a<<" loss :( ****";
			}
		}
		//cout<<"\nplayer"<<--player<<" win";
	else
		cout<<endl<<"***Game Draw***";
        cin.ignore();
        cin.get();//Game again
        return 0;
}
/*
OUTPUT:-
	***Welcome to tic toe Game***
Enter player name= 11
22
 player 1= 11
player 2= 22
	 _____________________________
	|____1____|____2____|____3____|
	|____4____|____5____|____6____|
	|____7____|____8____|____9____|

Player= 1
Enter pos= 1
	 _____________________________
	|____x____|____2____|____3____|
	|____4____|____5____|____6____|
	|____7____|____8____|____9____|
Player= 2
Enter pos= 2
	 _____________________________
	|____x____|____o____|____3____|
	|____4____|____5____|____6____|
	|____7____|____8____|____9____|

Player= 1
Enter pos= 4
	 ____________________________
	|____x____|____o____|____3____|
	|____x____|____5____|____6____|
	|____7____|____8____|____9____|

Player= 2
Enter pos= 5
	 _____________________________
	|____x____|____o____|____3____|
	|____x____|____o____|____6____|
	|____7____|____8____|____9____|

Player= 1
Enter pos= 7
	 _____________________________
	|____x____|____o____|____3____|
	|____x____|____o____|____6____|
	|____x____|____8____|____9____|

**** Player 11 win ;) ****
**** Player 22 loss :( ****
*/
